local Config = {}

Config.FONT_PATH = "assets/DejaVuSans.ttf"

Config.SAVE_HISTORY = true
Config.USE_BOOKMARKS = true

Config.LOG_SHOW_CONSOLE = true
Config.LOG_SAVE_FILE = true


return Config