function love.conf(t)
    t.window.title = "IPTV Viewer"
    t.window.width = 800
    t.window.height = 600
end